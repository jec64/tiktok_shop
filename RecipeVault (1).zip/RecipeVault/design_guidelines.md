# Design Guidelines: Digital Sales Management Platform

## Design Approach
**Reference-Based Approach**: Drawing inspiration from Kiwify and Hotmart's modern SaaS dashboard patterns, focusing on clean data presentation, intuitive navigation, and professional polish suitable for financial/sales management platforms.

## Core Design Principles
- **Information Hierarchy**: Clear distinction between primary metrics, secondary data, and actions
- **Data-First Design**: Content drives layout decisions; charts and tables are heroes
- **Professional Polish**: Smooth interactions and refined details that inspire trust
- **Efficiency**: Quick access to key actions and data across all pages

---

## Typography System

**Font Families**: 
- Primary: Inter for UI elements, data tables, labels
- Accent: Poppins for headings and emphasized content

**Hierarchy**:
- Dashboard Headings: text-3xl font-semibold (Poppins)
- Section Titles: text-2xl font-semibold (Poppins)
- Card Titles: text-lg font-medium (Inter)
- Body Text: text-base font-normal (Inter)
- Data/Metrics: text-sm to text-xl font-semibold depending on emphasis
- Labels: text-sm font-medium
- Helper Text: text-xs text-gray-600

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16** consistently
- Component padding: p-4 to p-8
- Section spacing: space-y-6 to space-y-8
- Card gaps: gap-4 to gap-6
- Page margins: p-6 to p-8

**Grid Structure**:
- Sidebar: Fixed width 256px (w-64) on desktop, collapsible on mobile
- Main Content: flex-1 with max-w-7xl container, px-6 to px-8
- Dashboard Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6
- Product/Sales Tables: Full width with horizontal scroll on mobile

---

## Navigation Structure

**Fixed Sidebar** (Desktop):
- Width: 256px, full height
- Logo at top (h-16 with p-4)
- Navigation items with icons (h-12, pl-4, flex items-center)
- Active state: subtle background treatment, font-medium
- Hover: smooth background transition
- User profile section at bottom (p-4)
- Icons from Heroicons (outline for inactive, solid for active)

**Mobile Navigation**:
- Hamburger menu (top-left)
- Slide-out drawer with same structure
- Bottom tab bar for primary sections (optional for better mobile UX)

---

## Component Library

### Dashboard Cards
- Box with rounded corners (rounded-lg)
- Padding: p-6
- Shadow: shadow-sm with subtle border
- Title: text-sm font-medium
- Metric Value: text-3xl font-bold (Poppins)
- Subtext: text-xs showing percentage/comparison
- Icon: w-12 h-12 in top-right corner (subtle treatment)

### Charts
- Chart.js integration for line/bar charts
- Height: h-80 for dashboard charts
- Padding within container: p-6
- Responsive axes and tooltips
- 7-day view with day labels

### Data Tables
- Header: sticky top-0, font-medium, text-sm
- Row height: h-16 with py-4 px-6
- Borders: border-b on rows
- Hover: subtle background change
- Actions column: flex gap-2 with icon buttons (w-8 h-8)
- Pagination: flex justify-between items-center mt-6

### Forms & Modals
- Modal: max-w-2xl centered, p-6 to p-8
- Input fields: h-12, px-4, rounded-lg with border
- Labels: text-sm font-medium, mb-2
- Buttons: h-12, px-6, rounded-lg font-medium
- Form spacing: space-y-6

### Buttons
- Primary: h-12, px-6, rounded-lg, font-medium
- Secondary: Same size, outlined variant
- Icon buttons: w-10 h-10, rounded-lg
- Hover: subtle scale (scale-105) with transition
- Disabled: opacity-50 cursor-not-allowed

### Status Badges
- Pill shape (rounded-full), px-3, py-1
- Text: text-xs font-medium
- Variants: Success (verde), Warning (amarelo), Error (vermelho), Pending (cinza)

---

## Page-Specific Layouts

### Dashboard
- 4-column metric cards at top (grid-cols-4)
- Sales chart below (col-span-3 in 4-column grid)
- Recent activity sidebar (col-span-1)
- Month comparison section (2 columns)

### Products Page
- Search bar + "Add Product" button (flex justify-between, mb-6)
- Filters row (flex gap-4)
- Product grid or table with image thumbnails (w-12 h-12 rounded)
- Product modal: 2-column form layout for details

### Sales Page
- Filter bar with date range picker and status dropdown
- Full-width table with horizontal scroll
- Export CSV button (top-right)
- Pagination at bottom

### Financial Page
- 3-column balance cards at top
- "Request Withdrawal" button (prominent, h-14, large)
- Withdrawal history table
- Transaction timeline with status indicators

### My Account
- Split layout: 2-column on desktop
- Left: Profile photo upload (w-32 h-32 rounded-full) + basic info
- Right: Editable form fields + change password section
- Plan badge (prominent display)

### Admin Panel
- Tabs for different admin sections (Users, Withdrawals, Banners, Dashboard)
- User management: table with action buttons (Approve, Ban, Promote)
- Metrics overview: similar to main dashboard but platform-wide
- Latest users/sales sections (max-h-96 overflow-y-auto)

---

## Interaction Patterns

- **Hover States**: Smooth 150ms transitions on all interactive elements
- **Loading States**: Skeleton screens for tables/cards, spinner for actions
- **Notifications**: Toast messages (top-right, slide-in animation, auto-dismiss)
- **Confirmations**: Modal dialogs for destructive actions (Delete, Ban)
- **Empty States**: Centered illustrations + CTA for empty tables/lists

---

## Responsive Behavior

**Mobile (< 768px)**:
- Sidebar collapses to hamburger menu
- Dashboard cards stack (grid-cols-1)
- Tables convert to card-based mobile view
- Reduced padding (p-4)

**Tablet (768px - 1024px)**:
- 2-column grids where appropriate
- Sidebar visible but narrower option available

**Desktop (> 1024px)**:
- Full multi-column layouts
- Fixed sidebar always visible
- Generous spacing and larger hit targets

---

## Images

**Profile Photos**: User avatars throughout (w-10 h-10 rounded-full for nav, w-32 h-32 for profile page)

**Product Thumbnails**: 64x64px rounded images in product lists, larger preview in modals

**Empty State Illustrations**: Simple, modern SVG illustrations for empty products/sales lists

**Banners**: Admin-managed promotional banners (16:9 aspect ratio, max-w-4xl)

**No Hero Image**: This is a dashboard application - focus remains on data and functionality, not marketing imagery