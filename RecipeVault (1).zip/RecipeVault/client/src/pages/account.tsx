import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Upload, Key } from "lucide-react";
import avatarPlaceholder from "@assets/generated_images/Professional_avatar_placeholder_b0f6a552.png";

export default function Account() {
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);

  // TODO: remove mock data
  const userData = {
    name: "João Silva",
    email: "joao@email.com",
    cpf: "123.456.789-00",
    pixKey: "joao@email.com",
    plan: "Premium",
    joinDate: "2024-01-15",
    photo: avatarPlaceholder,
  };

  const handleUpdateProfile = () => {
    console.log("Perfil atualizado");
  };

  const handleChangePassword = () => {
    console.log("Senha alterada");
    setIsPasswordDialogOpen(false);
  };

  const handlePhotoUpload = () => {
    console.log("Upload de foto iniciado");
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
          Minha Conta
        </h1>
        <p className="text-muted-foreground mt-1">
          Gerencie suas informações pessoais
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Foto de Perfil</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            <Avatar className="h-32 w-32">
              <AvatarImage src={userData.photo} alt={userData.name} />
              <AvatarFallback>JS</AvatarFallback>
            </Avatar>
            <Button variant="outline" onClick={handlePhotoUpload} data-testid="button-upload-photo">
              <Upload className="h-4 w-4 mr-2" />
              Alterar Foto
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Informações Pessoais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Nome Completo</Label>
                <Input
                  id="name"
                  defaultValue={userData.name}
                  data-testid="input-name"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  defaultValue={userData.email}
                  disabled
                  className="bg-muted"
                  data-testid="input-email"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="cpf">CPF</Label>
                <Input
                  id="cpf"
                  defaultValue={userData.cpf}
                  data-testid="input-cpf"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="pixKey">Chave Pix</Label>
                <Input
                  id="pixKey"
                  defaultValue={userData.pixKey}
                  data-testid="input-pix-key"
                />
              </div>
            </div>
            <div className="flex items-center gap-4 pt-4">
              <Button onClick={handleUpdateProfile} data-testid="button-save-profile">
                Salvar Alterações
              </Button>
              <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" data-testid="button-change-password">
                    <Key className="h-4 w-4 mr-2" />
                    Alterar Senha
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Alterar Senha</DialogTitle>
                    <DialogDescription>
                      Digite sua senha atual e a nova senha
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="currentPassword">Senha Atual</Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        data-testid="input-current-password"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="newPassword">Nova Senha</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        data-testid="input-new-password"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        data-testid="input-confirm-password"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsPasswordDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleChangePassword} data-testid="button-confirm-password">
                      Confirmar
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Informações da Conta</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Plano Atual</p>
              <p className="text-xs text-muted-foreground">Seu plano ativo</p>
            </div>
            <Badge className="text-base px-4 py-1" data-testid="badge-plan">
              {userData.plan}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Membro desde</p>
              <p className="text-xs text-muted-foreground">Data de cadastro</p>
            </div>
            <p className="text-sm font-semibold">
              {new Date(userData.joinDate).toLocaleDateString("pt-BR", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
