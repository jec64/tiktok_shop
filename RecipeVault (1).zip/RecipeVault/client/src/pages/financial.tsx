import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Wallet, DollarSign, Clock, TrendingUp } from "lucide-react";

export default function Financial() {
  const [isWithdrawalDialogOpen, setIsWithdrawalDialogOpen] = useState(false);

  // TODO: remove mock data
  const balanceData = {
    total: 48542.30,
    retained: 12340.50,
    available: 36201.80,
  };

  const withdrawals = [
    {
      id: "SAQ-001",
      amount: 5000.00,
      pixKey: "joao@email.com",
      status: "aprovado",
      requestDate: "2024-11-05",
      processedDate: "2024-11-06",
    },
    {
      id: "SAQ-002",
      amount: 2500.00,
      pixKey: "joao@email.com",
      status: "pendente",
      requestDate: "2024-11-08",
      processedDate: null,
    },
  ];

  const transactions = [
    { id: 1, type: "Venda", description: "Curso de Marketing Digital", amount: 297.00, fee: 14.76, date: "2024-11-08" },
    { id: 2, type: "Venda", description: "E-book de Vendas", amount: 47.00, fee: 1.41, date: "2024-11-08" },
    { id: 3, type: "Saque", description: "Transferência Pix", amount: -5000.00, fee: 0, date: "2024-11-06" },
  ];

  const handleRequestWithdrawal = () => {
    console.log("Saque solicitado");
    setIsWithdrawalDialogOpen(false);
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "aprovado":
        return "default";
      case "pendente":
        return "secondary";
      case "reprovado":
        return "destructive";
      default:
        return "secondary";
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
          Financeiro
        </h1>
        <p className="text-muted-foreground mt-1">
          Gerencie seus ganhos e saques
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card data-testid="card-saldo-total">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo Total</CardTitle>
            <DollarSign className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              R$ {balanceData.total.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Total acumulado
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-saldo-retido">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo Retido</CardTitle>
            <Clock className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              R$ {balanceData.retained.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Liberação em 45 dias
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-saldo-disponivel">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo Disponível</CardTitle>
            <Wallet className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary" style={{ fontFamily: "Poppins, sans-serif" }}>
              R$ {balanceData.available.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Pronto para saque
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-between gap-4">
        <h2 className="text-xl font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
          Solicitar Saque
        </h2>
        <Dialog open={isWithdrawalDialogOpen} onOpenChange={setIsWithdrawalDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" data-testid="button-request-withdrawal">
              <TrendingUp className="h-4 w-4 mr-2" />
              Solicitar Saque
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Solicitar Saque</DialogTitle>
              <DialogDescription>
                Informe o valor que deseja sacar. O valor será transferido via Pix.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="amount">Valor (R$)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  max={balanceData.available}
                  data-testid="input-withdrawal-amount"
                />
                <p className="text-xs text-muted-foreground">
                  Disponível: R$ {balanceData.available.toFixed(2)}
                </p>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="pixKey">Chave Pix</Label>
                <Input
                  id="pixKey"
                  placeholder="email@exemplo.com"
                  data-testid="input-pix-key"
                />
              </div>
              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="font-medium mb-2">Taxas de Processamento</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Cartão de Crédito: 4,99% + R$ 2,59</li>
                  <li>• Pix: 2,99%</li>
                </ul>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsWithdrawalDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleRequestWithdrawal} data-testid="button-confirm-withdrawal">
                Confirmar Saque
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Saques</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Chave Pix</TableHead>
                <TableHead>Data Solicitação</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {withdrawals.map((withdrawal) => (
                <TableRow key={withdrawal.id} data-testid={`row-withdrawal-${withdrawal.id}`}>
                  <TableCell className="font-medium">{withdrawal.id}</TableCell>
                  <TableCell>R$ {withdrawal.amount.toFixed(2)}</TableCell>
                  <TableCell>{withdrawal.pixKey}</TableCell>
                  <TableCell>
                    {new Date(withdrawal.requestDate).toLocaleDateString("pt-BR")}
                  </TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(withdrawal.status)}>
                      {withdrawal.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Transações</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tipo</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Taxa</TableHead>
                <TableHead>Data</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell className="font-medium">{transaction.type}</TableCell>
                  <TableCell>{transaction.description}</TableCell>
                  <TableCell className={transaction.amount > 0 ? "text-primary" : ""}>
                    R$ {transaction.amount.toFixed(2)}
                  </TableCell>
                  <TableCell>R$ {transaction.fee.toFixed(2)}</TableCell>
                  <TableCell>
                    {new Date(transaction.date).toLocaleDateString("pt-BR")}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
