import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download, Search } from "lucide-react";

export default function Sales() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");

  // TODO: remove mock data
  const sales = [
    {
      id: "VEN-001",
      product: "Curso de Marketing Digital",
      customer: "Maria Santos",
      amount: 297.00,
      date: "2024-11-08T10:30:00",
      status: "pago",
      paymentMethod: "cartao",
    },
    {
      id: "VEN-002",
      product: "E-book de Vendas Online",
      customer: "João Silva",
      amount: 47.00,
      date: "2024-11-08T09:15:00",
      status: "pago",
      paymentMethod: "pix",
    },
    {
      id: "VEN-003",
      product: "Mentoria 1:1",
      customer: "Ana Costa",
      amount: 997.00,
      date: "2024-11-07T16:45:00",
      status: "pendente",
      paymentMethod: "cartao",
    },
    {
      id: "VEN-004",
      product: "Curso de Marketing Digital",
      customer: "Pedro Oliveira",
      amount: 297.00,
      date: "2024-11-07T14:20:00",
      status: "estornado",
      paymentMethod: "cartao",
    },
  ];

  const filteredSales = sales.filter((sale) => {
    const matchesSearch =
      sale.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.product.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "todos" || sale.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "pago":
        return "default";
      case "pendente":
        return "secondary";
      case "estornado":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const handleExportCSV = () => {
    console.log("Exportando vendas para CSV");
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
            Vendas
          </h1>
          <p className="text-muted-foreground mt-1">
            Acompanhe todas as suas transações
          </p>
        </div>
        <Button variant="outline" onClick={handleExportCSV} data-testid="button-export-csv">
          <Download className="h-4 w-4 mr-2" />
          Exportar CSV
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-6 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar vendas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-sales"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]" data-testid="select-status-filter">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os status</SelectItem>
                <SelectItem value="pago">Pago</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="estornado">Estornado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Método</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSales.map((sale) => (
                <TableRow key={sale.id} data-testid={`row-sale-${sale.id}`}>
                  <TableCell className="font-medium">{sale.id}</TableCell>
                  <TableCell>{sale.product}</TableCell>
                  <TableCell>{sale.customer}</TableCell>
                  <TableCell>R$ {sale.amount.toFixed(2)}</TableCell>
                  <TableCell>
                    {new Date(sale.date).toLocaleDateString("pt-BR")} às{" "}
                    {new Date(sale.date).toLocaleTimeString("pt-BR", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </TableCell>
                  <TableCell className="capitalize">{sale.paymentMethod}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(sale.status)}>
                      {sale.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
