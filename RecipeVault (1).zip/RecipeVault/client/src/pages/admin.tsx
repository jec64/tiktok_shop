import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, DollarSign, TrendingUp, CheckCircle, XCircle, UserPlus } from "lucide-react";

export default function Admin() {
  // TODO: remove mock data
  const stats = {
    totalUsers: 1234,
    totalSales: 48542.30,
    pendingWithdrawals: 7250.00,
    newUsersToday: 12,
  };

  const pendingUsers = [
    { id: "1", name: "Carlos Mendes", email: "carlos@email.com", date: "2024-11-08" },
    { id: "2", name: "Ana Paula", email: "ana@email.com", date: "2024-11-08" },
  ];

  const pendingWithdrawals = [
    { id: "SAQ-003", user: "Maria Santos", amount: 3500.00, date: "2024-11-08" },
    { id: "SAQ-004", user: "Pedro Costa", amount: 2100.00, date: "2024-11-07" },
  ];

  const recentUsers = [
    { id: "1", name: "João Silva", email: "joao@email.com", plan: "Premium", status: "ativo" },
    { id: "2", name: "Maria Santos", email: "maria@email.com", plan: "Free", status: "ativo" },
    { id: "3", name: "Pedro Costa", email: "pedro@email.com", plan: "Premium", status: "banido" },
  ];

  const recentSales = [
    { id: "VEN-001", product: "Curso Marketing", user: "João Silva", amount: 297.00, date: "2024-11-08" },
    { id: "VEN-002", product: "E-book Vendas", user: "Ana Costa", amount: 47.00, date: "2024-11-08" },
  ];

  const handleApproveUser = (userId: string) => {
    console.log(`Usuário ${userId} aprovado`);
  };

  const handleRejectUser = (userId: string) => {
    console.log(`Usuário ${userId} reprovado`);
  };

  const handleApproveWithdrawal = (withdrawalId: string) => {
    console.log(`Saque ${withdrawalId} aprovado`);
  };

  const handleRejectWithdrawal = (withdrawalId: string) => {
    console.log(`Saque ${withdrawalId} reprovado`);
  };

  const handlePromoteToAdmin = (userId: string) => {
    console.log(`Usuário ${userId} promovido a admin`);
  };

  const handleBanUser = (userId: string) => {
    console.log(`Usuário ${userId} banido`);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
          Painel Administrativo
        </h1>
        <p className="text-muted-foreground mt-1">
          Visão geral e gerenciamento da plataforma
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card data-testid="card-total-users">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
            <Users className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              {stats.totalUsers}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              +{stats.newUsersToday} hoje
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-total-sales-admin">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total em Vendas</CardTitle>
            <DollarSign className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              R$ {stats.totalSales.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Todos os usuários
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-pending-withdrawals-admin">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saques Pendentes</CardTitle>
            <TrendingUp className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              R$ {stats.pendingWithdrawals.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Aguardando aprovação
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-new-users">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Novos Usuários</CardTitle>
            <UserPlus className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              {stats.newUsersToday}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Hoje
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" data-testid="tabs-admin">
        <TabsList>
          <TabsTrigger value="pending">Pendências</TabsTrigger>
          <TabsTrigger value="users">Usuários</TabsTrigger>
          <TabsTrigger value="activity">Atividade Recente</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Cadastros Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{new Date(user.date).toLocaleDateString("pt-BR")}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleApproveUser(user.id)}
                            data-testid={`button-approve-user-${user.id}`}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Aprovar
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRejectUser(user.id)}
                            data-testid={`button-reject-user-${user.id}`}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reprovar
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Saques Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingWithdrawals.map((withdrawal) => (
                    <TableRow key={withdrawal.id}>
                      <TableCell className="font-medium">{withdrawal.id}</TableCell>
                      <TableCell>{withdrawal.user}</TableCell>
                      <TableCell>R$ {withdrawal.amount.toFixed(2)}</TableCell>
                      <TableCell>{new Date(withdrawal.date).toLocaleDateString("pt-BR")}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleApproveWithdrawal(withdrawal.id)}
                            data-testid={`button-approve-withdrawal-${withdrawal.id}`}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Aprovar
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRejectWithdrawal(withdrawal.id)}
                            data-testid={`button-reject-withdrawal-${withdrawal.id}`}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reprovar
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciar Usuários</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Plano</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src="" alt={user.name} />
                            <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{user.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.plan}</TableCell>
                      <TableCell>
                        <Badge variant={user.status === "ativo" ? "default" : "destructive"}>
                          {user.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handlePromoteToAdmin(user.id)}
                            data-testid={`button-promote-${user.id}`}
                          >
                            Promover
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleBanUser(user.id)}
                            data-testid={`button-ban-${user.id}`}
                          >
                            Banir
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Últimos Usuários Cadastrados</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Plano</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentUsers.slice(0, 5).map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.plan}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Últimas Vendas</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Produto</TableHead>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Data</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentSales.map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">{sale.id}</TableCell>
                      <TableCell>{sale.product}</TableCell>
                      <TableCell>{sale.user}</TableCell>
                      <TableCell>R$ {sale.amount.toFixed(2)}</TableCell>
                      <TableCell>{new Date(sale.date).toLocaleDateString("pt-BR")}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
