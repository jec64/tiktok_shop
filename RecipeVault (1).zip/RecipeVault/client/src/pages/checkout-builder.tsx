import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Eye, Save, Copy, Clock, Image as ImageIcon, Zap } from "lucide-react";

export default function CheckoutBuilder() {
  const [checkoutConfig, setCheckoutConfig] = useState({
    productName: "Meu Produto",
    productDescription: "Descrição do produto",
    price: 297.00,
    installments: 12,
    enableTimer: false,
    timerMinutes: 15,
    enableBanner: false,
    bannerText: "🔥 Oferta por tempo limitado!",
    bannerColor: "#FF6B6B",
    enableOrderBump: false,
    orderBumpName: "Produto Bônus",
    orderBumpPrice: 47.00,
    enableGuarantee: true,
    guaranteeDays: 7,
    buttonText: "Comprar Agora",
    buttonColor: "#6B4EFF",
  });

  const handleConfigChange = (key: string, value: any) => {
    setCheckoutConfig({ ...checkoutConfig, [key]: value });
  };

  const handleSave = () => {
    console.log("Checkout salvo:", checkoutConfig);
  };

  const handleCopyLink = () => {
    console.log("Link copiado");
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
            Checkout Builder
          </h1>
          <p className="text-muted-foreground mt-1">
            Personalize sua página de checkout profissional
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" data-testid="button-preview-checkout">
            <Eye className="h-4 w-4 mr-2" />
            Visualizar
          </Button>
          <Button onClick={handleSave} data-testid="button-save-checkout">
            <Save className="h-4 w-4 mr-2" />
            Salvar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                Informações do Produto
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="productName">Nome do Produto</Label>
                <Input
                  id="productName"
                  value={checkoutConfig.productName}
                  onChange={(e) => handleConfigChange("productName", e.target.value)}
                  data-testid="input-product-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="productDescription">Descrição</Label>
                <Textarea
                  id="productDescription"
                  value={checkoutConfig.productDescription}
                  onChange={(e) => handleConfigChange("productDescription", e.target.value)}
                  rows={3}
                  data-testid="input-product-description"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Preço (R$)</Label>
                  <Input
                    id="price"
                    type="number"
                    value={checkoutConfig.price}
                    onChange={(e) => handleConfigChange("price", parseFloat(e.target.value))}
                    data-testid="input-price"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="installments">Parcelas</Label>
                  <Select
                    value={checkoutConfig.installments.toString()}
                    onValueChange={(value) => handleConfigChange("installments", parseInt(value))}
                  >
                    <SelectTrigger data-testid="select-installments">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 6, 12].map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          {num}x
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                Cronômetro de Urgência
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enableTimer" className="text-base font-medium">
                    Ativar Cronômetro
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Aumenta conversão com senso de urgência
                  </p>
                </div>
                <Switch
                  id="enableTimer"
                  checked={checkoutConfig.enableTimer}
                  onCheckedChange={(checked) => handleConfigChange("enableTimer", checked)}
                  data-testid="switch-timer"
                />
              </div>
              {checkoutConfig.enableTimer && (
                <div className="space-y-2">
                  <Label htmlFor="timerMinutes">Tempo (minutos)</Label>
                  <Input
                    id="timerMinutes"
                    type="number"
                    value={checkoutConfig.timerMinutes}
                    onChange={(e) => handleConfigChange("timerMinutes", parseInt(e.target.value))}
                    data-testid="input-timer-minutes"
                  />
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ImageIcon className="h-5 w-5 text-primary" />
                Banner de Destaque
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enableBanner" className="text-base font-medium">
                    Ativar Banner
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Banner chamativo no topo da página
                  </p>
                </div>
                <Switch
                  id="enableBanner"
                  checked={checkoutConfig.enableBanner}
                  onCheckedChange={(checked) => handleConfigChange("enableBanner", checked)}
                  data-testid="switch-banner"
                />
              </div>
              {checkoutConfig.enableBanner && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bannerText">Texto do Banner</Label>
                    <Input
                      id="bannerText"
                      value={checkoutConfig.bannerText}
                      onChange={(e) => handleConfigChange("bannerText", e.target.value)}
                      data-testid="input-banner-text"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bannerColor">Cor do Banner</Label>
                    <Input
                      id="bannerColor"
                      type="color"
                      value={checkoutConfig.bannerColor}
                      onChange={(e) => handleConfigChange("bannerColor", e.target.value)}
                      data-testid="input-banner-color"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Order Bump (Venda Adicional)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enableOrderBump" className="text-base font-medium">
                    Ativar Order Bump
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Ofereça produto adicional no checkout
                  </p>
                </div>
                <Switch
                  id="enableOrderBump"
                  checked={checkoutConfig.enableOrderBump}
                  onCheckedChange={(checked) => handleConfigChange("enableOrderBump", checked)}
                  data-testid="switch-order-bump"
                />
              </div>
              {checkoutConfig.enableOrderBump && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="orderBumpName">Nome do Produto Bônus</Label>
                    <Input
                      id="orderBumpName"
                      value={checkoutConfig.orderBumpName}
                      onChange={(e) => handleConfigChange("orderBumpName", e.target.value)}
                      data-testid="input-order-bump-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="orderBumpPrice">Preço (R$)</Label>
                    <Input
                      id="orderBumpPrice"
                      type="number"
                      value={checkoutConfig.orderBumpPrice}
                      onChange={(e) => handleConfigChange("orderBumpPrice", parseFloat(e.target.value))}
                      data-testid="input-order-bump-price"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Personalização do Botão</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="buttonText">Texto do Botão</Label>
                <Input
                  id="buttonText"
                  value={checkoutConfig.buttonText}
                  onChange={(e) => handleConfigChange("buttonText", e.target.value)}
                  data-testid="input-button-text"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="buttonColor">Cor do Botão</Label>
                <Input
                  id="buttonColor"
                  type="color"
                  value={checkoutConfig.buttonColor}
                  onChange={(e) => handleConfigChange("buttonColor", e.target.value)}
                  data-testid="input-button-color"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:sticky lg:top-8 h-fit">
          <Card>
            <CardHeader>
              <CardTitle>Preview do Checkout</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden bg-background">
                {checkoutConfig.enableBanner && (
                  <div
                    className="p-4 text-center text-white font-semibold"
                    style={{ backgroundColor: checkoutConfig.bannerColor }}
                  >
                    {checkoutConfig.bannerText}
                  </div>
                )}
                
                <div className="p-8 space-y-6">
                  <div className="text-center space-y-2">
                    <h2 className="text-2xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
                      {checkoutConfig.productName}
                    </h2>
                    <p className="text-muted-foreground">
                      {checkoutConfig.productDescription}
                    </p>
                  </div>

                  {checkoutConfig.enableTimer && (
                    <div className="bg-muted rounded-lg p-4 text-center">
                      <p className="text-sm font-medium mb-2">Oferta expira em:</p>
                      <div className="flex items-center justify-center gap-2 text-2xl font-bold text-primary">
                        <span>00:{checkoutConfig.timerMinutes.toString().padStart(2, '0')}:00</span>
                      </div>
                    </div>
                  )}

                  <div className="text-center space-y-2">
                    <div className="text-4xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
                      R$ {checkoutConfig.price.toFixed(2)}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      ou {checkoutConfig.installments}x de R${" "}
                      {(checkoutConfig.price / checkoutConfig.installments).toFixed(2)}
                    </p>
                  </div>

                  {checkoutConfig.enableOrderBump && (
                    <div className="border-2 border-primary rounded-lg p-4 bg-primary/5">
                      <div className="flex items-start gap-3">
                        <input type="checkbox" className="mt-1" />
                        <div className="flex-1">
                          <p className="font-semibold">
                            ✅ Sim! Quero adicionar {checkoutConfig.orderBumpName}
                          </p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Por apenas R$ {checkoutConfig.orderBumpPrice.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <Button
                    className="w-full h-14 text-lg font-semibold"
                    style={{ backgroundColor: checkoutConfig.buttonColor }}
                    data-testid="preview-checkout-button"
                  >
                    {checkoutConfig.buttonText}
                  </Button>

                  {checkoutConfig.enableGuarantee && (
                    <div className="text-center text-sm text-muted-foreground">
                      🔒 Garantia de {checkoutConfig.guaranteeDays} dias
                    </div>
                  )}
                </div>
              </div>

              <Separator className="my-6" />

              <div className="space-y-4">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={handleCopyLink}
                  data-testid="button-copy-link"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copiar Link do Checkout
                </Button>
                <div className="text-xs text-muted-foreground text-center">
                  Link: vendapro.com/checkout/{checkoutConfig.productName.toLowerCase().replace(/\s+/g, '-')}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
