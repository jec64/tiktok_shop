import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";

export default function Register() {
  const [documentType, setDocumentType] = useState<"cpf" | "cnpj">("cpf");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    cpf: "",
    cnpj: "",
    companyName: "",
    password: "",
    confirmPassword: "",
  });

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Registro iniciado", formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.id]: e.target.value,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-muted/50">
      <Card className="w-full max-w-lg">
        <CardHeader className="space-y-1 text-center">
          <div className="mx-auto w-12 h-12 rounded-lg bg-primary flex items-center justify-center mb-4">
            <span className="text-primary-foreground font-bold text-xl">V</span>
          </div>
          <CardTitle className="text-2xl" style={{ fontFamily: "Poppins, sans-serif" }}>
            Criar Conta
          </CardTitle>
          <CardDescription>
            Preencha seus dados para começar a vender
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={documentType} onValueChange={(value) => setDocumentType(value as "cpf" | "cnpj")} className="mb-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="cpf" data-testid="tab-cpf">Pessoa Física</TabsTrigger>
              <TabsTrigger value="cnpj" data-testid="tab-cnpj">Pessoa Jurídica</TabsTrigger>
            </TabsList>
          </Tabs>

          <form onSubmit={handleRegister} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">{documentType === "cpf" ? "Nome Completo" : "Razão Social"}</Label>
              <Input
                id="name"
                placeholder={documentType === "cpf" ? "João Silva" : "Empresa LTDA"}
                value={formData.name}
                onChange={handleChange}
                required
                data-testid="input-register-name"
              />
            </div>

            {documentType === "cnpj" && (
              <div className="space-y-2">
                <Label htmlFor="companyName">Nome Fantasia</Label>
                <Input
                  id="companyName"
                  placeholder="Minha Empresa"
                  value={formData.companyName}
                  onChange={handleChange}
                  data-testid="input-register-company-name"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={handleChange}
                required
                data-testid="input-register-email"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor={documentType === "cpf" ? "cpf" : "cnpj"}>
                {documentType === "cpf" ? "CPF" : "CNPJ"}
              </Label>
              <Input
                id={documentType === "cpf" ? "cpf" : "cnpj"}
                placeholder={documentType === "cpf" ? "000.000.000-00" : "00.000.000/0000-00"}
                value={documentType === "cpf" ? formData.cpf : formData.cnpj}
                onChange={handleChange}
                required
                data-testid={`input-register-${documentType}`}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={handleChange}
                required
                data-testid="input-register-password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                data-testid="input-register-confirm-password"
              />
            </div>

            <Button type="submit" className="w-full" data-testid="button-register">
              Criar Conta
            </Button>
          </form>
          <div className="mt-6 text-center text-sm">
            <span className="text-muted-foreground">Já tem uma conta? </span>
            <Link href="/login" className="text-primary hover:underline" data-testid="link-login">
              Fazer login
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
