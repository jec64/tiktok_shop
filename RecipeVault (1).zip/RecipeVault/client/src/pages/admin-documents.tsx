import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Search, FileText, CheckCircle, XCircle, Eye } from "lucide-react";

export default function AdminDocuments() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDocument, setSelectedDocument] = useState<any>(null);

  // TODO: remove mock data
  const documents = [
    {
      id: "1",
      userName: "João Silva",
      userEmail: "joao@email.com",
      documentType: "RG",
      documentNumber: "12.345.678-9",
      uploadDate: "2024-11-08",
      status: "pendente",
      fileUrl: "/docs/rg-joao.pdf",
    },
    {
      id: "2",
      userName: "Maria Santos",
      userEmail: "maria@email.com",
      documentType: "CNH",
      documentNumber: "98765432109",
      uploadDate: "2024-11-07",
      status: "aprovado",
      fileUrl: "/docs/cnh-maria.pdf",
    },
    {
      id: "3",
      userName: "Pedro Costa",
      userEmail: "pedro@email.com",
      documentType: "Comprovante de Residência",
      documentNumber: "-",
      uploadDate: "2024-11-06",
      status: "reprovado",
      fileUrl: "/docs/comprovante-pedro.pdf",
      rejectionReason: "Documento ilegível",
    },
  ];

  const filteredDocuments = documents.filter((doc) =>
    doc.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.documentType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleApprove = (docId: string) => {
    console.log(`Documento ${docId} aprovado`);
  };

  const handleReject = (docId: string) => {
    console.log(`Documento ${docId} reprovado`);
  };

  const handleViewDocument = (doc: any) => {
    setSelectedDocument(doc);
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "aprovado":
        return "default";
      case "pendente":
        return "secondary";
      case "reprovado":
        return "destructive";
      default:
        return "secondary";
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold" style={{ fontFamily: "Poppins, sans-serif" }}>
          Documentos de Usuários
        </h1>
        <p className="text-muted-foreground mt-1">
          Analise e aprove documentos enviados pelos usuários
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            <FileText className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              {documents.filter(d => d.status === "pendente").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aprovados</CardTitle>
            <CheckCircle className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              {documents.filter(d => d.status === "aprovado").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reprovados</CardTitle>
            <XCircle className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>
              {documents.filter(d => d.status === "reprovado").length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por usuário ou tipo de documento..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-documents"
            />
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Usuário</TableHead>
                <TableHead>Tipo de Documento</TableHead>
                <TableHead>Número</TableHead>
                <TableHead>Data de Envio</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDocuments.map((doc) => (
                <TableRow key={doc.id} data-testid={`row-document-${doc.id}`}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="" alt={doc.userName} />
                        <AvatarFallback>
                          {doc.userName.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{doc.userName}</div>
                        <div className="text-xs text-muted-foreground">{doc.userEmail}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{doc.documentType}</TableCell>
                  <TableCell className="font-mono text-sm">{doc.documentNumber}</TableCell>
                  <TableCell>{new Date(doc.uploadDate).toLocaleDateString("pt-BR")}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(doc.status)}>
                      {doc.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewDocument(doc)}
                        data-testid={`button-view-${doc.id}`}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Ver
                      </Button>
                      {doc.status === "pendente" && (
                        <>
                          <Button
                            size="sm"
                            onClick={() => handleApprove(doc.id)}
                            data-testid={`button-approve-doc-${doc.id}`}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Aprovar
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleReject(doc.id)}
                            data-testid={`button-reject-doc-${doc.id}`}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reprovar
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!selectedDocument} onOpenChange={() => setSelectedDocument(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Visualizar Documento</DialogTitle>
          </DialogHeader>
          {selectedDocument && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Usuário:</span>
                  <p className="font-medium">{selectedDocument.userName}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Tipo:</span>
                  <p className="font-medium">{selectedDocument.documentType}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Número:</span>
                  <p className="font-medium font-mono">{selectedDocument.documentNumber}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Data de Envio:</span>
                  <p className="font-medium">
                    {new Date(selectedDocument.uploadDate).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              </div>
              <div className="border rounded-lg bg-muted/50 h-96 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <FileText className="h-16 w-16 mx-auto mb-4" />
                  <p>Visualização do documento</p>
                  <p className="text-sm">{selectedDocument.fileUrl}</p>
                </div>
              </div>
              {selectedDocument.status === "reprovado" && selectedDocument.rejectionReason && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                  <p className="text-sm font-medium text-destructive">Motivo da Reprovação:</p>
                  <p className="text-sm mt-1">{selectedDocument.rejectionReason}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
