import CheckoutBuilder from "../../pages/checkout-builder";

export default function CheckoutBuilderExample() {
  return <CheckoutBuilder />;
}
