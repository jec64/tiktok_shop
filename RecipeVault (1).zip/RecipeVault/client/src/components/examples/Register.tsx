import Register from "../../pages/register";

export default function RegisterExample() {
  return <Register />;
}
