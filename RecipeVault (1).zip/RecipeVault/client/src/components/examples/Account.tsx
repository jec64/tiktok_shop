import Account from "../../pages/account";

export default function AccountExample() {
  return <Account />;
}
