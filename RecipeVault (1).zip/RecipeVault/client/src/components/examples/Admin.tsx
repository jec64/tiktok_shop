import Admin from "../../pages/admin";

export default function AdminExample() {
  return <Admin />;
}
