import AdminDocuments from "../../pages/admin-documents";

export default function AdminDocumentsExample() {
  return <AdminDocuments />;
}
