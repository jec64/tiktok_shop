import Sales from "../../pages/sales";

export default function SalesExample() {
  return <Sales />;
}
