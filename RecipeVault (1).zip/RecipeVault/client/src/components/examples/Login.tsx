import Login from "../../pages/login";

export default function LoginExample() {
  return <Login />;
}
