import Financial from "../../pages/financial";

export default function FinancialExample() {
  return <Financial />;
}
