import Products from "../../pages/products";

export default function ProductsExample() {
  return <Products />;
}
